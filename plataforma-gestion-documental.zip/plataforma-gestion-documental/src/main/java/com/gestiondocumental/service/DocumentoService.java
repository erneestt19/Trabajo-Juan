package com.gestiondocumental.service;

import com.gestiondocumental.model.Documento;
import com.gestiondocumental.repository.DocumentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DocumentoService {

    @Autowired
    private DocumentoRepository documentoRepository;

    public List<Documento> obtenerTodosLosDocumentos() {
        return documentoRepository.findAll();
    }

    public List<Documento> obtenerDocumentosPorProyectoId(int proyectoId) {
        return documentoRepository.findByProyectoId(proyectoId);
    }

    public List<Documento> obtenerDocumentosPorTipo(String tipo) {
        return documentoRepository.findByTipo(tipo);
    }

    public Documento crearDocumento(Documento documento) {
        return documentoRepository.save(documento);
    }

    public void eliminarDocumento(int id) {
        documentoRepository.deleteById(id);
    }
}
