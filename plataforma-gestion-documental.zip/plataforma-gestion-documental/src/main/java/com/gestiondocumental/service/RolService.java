package com.gestiondocumental.service;

import com.gestiondocumental.model.Rol;
import com.gestiondocumental.repository.RolRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RolService {

    @Autowired
    private RolRepository rolRepository;

    public List<Rol> obtenerTodosLosRoles() {
        return rolRepository.findAll();
    }

    public Rol obtenerRolPorNombre(String nombre) {
        return rolRepository.findByNombre(nombre);
    }

    public Rol crearRol(Rol rol) {
        return rolRepository.save(rol);
    }
}
