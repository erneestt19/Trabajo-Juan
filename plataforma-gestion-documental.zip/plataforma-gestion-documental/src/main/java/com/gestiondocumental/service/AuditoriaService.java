package com.gestiondocumental.service;

import com.gestiondocumental.model.Auditoria;
import com.gestiondocumental.repository.AuditoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AuditoriaService {

    @Autowired
    private AuditoriaRepository auditoriaRepository;

    public List<Auditoria> obtenerTodasLasAuditorias() {
        return auditoriaRepository.findAll();
    }

    public List<Auditoria> obtenerAuditoriasPorUsuarioId(int usuarioId) {
        return auditoriaRepository.findByUsuarioId(usuarioId);
    }

    public List<Auditoria> obtenerAuditoriasPorRangoDeFechas(LocalDateTime inicio, LocalDateTime fin) {
        return auditoriaRepository.findByFechaHoraBetween(inicio, fin);
    }

    public Auditoria registrarAuditoria(Auditoria auditoria) {
        if (auditoria.getFechaHora() == null) {
            auditoria.setFechaHora(LocalDateTime.now());
        }
        return auditoriaRepository.save(auditoria);
    }
}