package com.gestiondocumental.service;

import com.gestiondocumental.model.Fase;
import com.gestiondocumental.repository.FaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FaseService {

    @Autowired
    private FaseRepository faseRepository;

    public List<Fase> obtenerTodasLasFases() {
        return faseRepository.findAll();
    }

    public Fase crearFase(Fase fase) {
        return faseRepository.save(fase);
    }
}
