package com.gestiondocumental.service;

import com.gestiondocumental.model.Proyecto;
import com.gestiondocumental.repository.ProyectoRepository;
import com.gestiondocumental.repository.FaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProyectoService {

    @Autowired
    private ProyectoRepository proyectoRepository;
    @Autowired
    private FaseRepository faseRepository;

    public List<Proyecto> obtenerTodosLosProyectos() {
        return proyectoRepository.findAll();
    }

    public List<Proyecto> obtenerProyectosPorUsuarioId(int usuarioId) {
        return proyectoRepository.findByUsuarioId(usuarioId);
    }

    public Proyecto crearProyecto(Proyecto proyecto) {
        if (proyecto.getFase() == null || !faseRepository.existsById(proyecto.getFase().getId())) {
            throw new IllegalArgumentException("La fase especificada no existe.");
        }
        return proyectoRepository.save(proyecto);
    }

    public void eliminarProyecto(int id) {
        proyectoRepository.deleteById(id);
    }
}
