package com.gestiondocumental;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlataformaGestionDocumentalApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlataformaGestionDocumentalApplication.class, args);
	}

}
