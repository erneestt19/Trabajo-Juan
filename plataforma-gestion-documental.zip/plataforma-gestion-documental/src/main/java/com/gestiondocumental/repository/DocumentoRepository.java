package com.gestiondocumental.repository;

import com.gestiondocumental.model.Documento;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DocumentoRepository extends JpaRepository<Documento, Integer> {
    // Buscar documentos por proyecto
    List<Documento> findByProyectoId(int proyectoId);

    // Buscar documentos por tipo
    List<Documento> findByTipo(String tipo);
}
