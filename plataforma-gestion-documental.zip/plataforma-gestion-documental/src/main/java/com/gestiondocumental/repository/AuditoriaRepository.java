package com.gestiondocumental.repository;

import com.gestiondocumental.model.Auditoria;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;

public interface AuditoriaRepository extends JpaRepository<Auditoria, Integer> {
    // Buscar auditorías por ID de usuario
    List<Auditoria> findByUsuarioId(int usuarioId);

    // Buscar auditorías dentro de un rango de fechas
    List<Auditoria> findByFechaHoraBetween(LocalDateTime inicio, LocalDateTime fin);
}
