package com.gestiondocumental.repository;

import com.gestiondocumental.model.Fase;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FaseRepository extends JpaRepository<Fase, Integer> {
}
