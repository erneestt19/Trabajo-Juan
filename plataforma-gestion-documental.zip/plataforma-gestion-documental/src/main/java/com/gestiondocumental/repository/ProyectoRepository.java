package com.gestiondocumental.repository;

import com.gestiondocumental.model.Proyecto;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProyectoRepository extends JpaRepository<Proyecto, Integer> {
    // Buscar proyectos por usuario
    List<Proyecto> findByUsuarioId(int usuarioId);

    // Buscar proyectos por fase
    List<Proyecto> findByFaseId(int faseId);

    // Buscar proyectos activos
    List<Proyecto> findByActivoTrue();
}
