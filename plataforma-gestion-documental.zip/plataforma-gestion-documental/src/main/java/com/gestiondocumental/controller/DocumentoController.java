package com.gestiondocumental.controller;

import com.gestiondocumental.model.Documento;
import com.gestiondocumental.service.DocumentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/documentos")
public class DocumentoController {

    @Autowired
    private DocumentoService documentoService;

    // Obtener todos los documentos
    @GetMapping
    public List<Documento> obtenerTodosLosDocumentos() {
        return documentoService.obtenerTodosLosDocumentos();
    }

    // Obtener documentos por proyecto
    @GetMapping("/proyecto/{proyectoId}")
    public List<Documento> obtenerDocumentosPorProyecto(@PathVariable int proyectoId) {
        return documentoService.obtenerDocumentosPorProyectoId(proyectoId);
    }

    // Obtener documentos por tipo
    @GetMapping("/tipo")
    public List<Documento> obtenerDocumentosPorTipo(@RequestParam String tipo) {
        return documentoService.obtenerDocumentosPorTipo(tipo);
    }

    // Crear un nuevo documento
    @PostMapping
    public ResponseEntity<Documento> crearDocumento(@RequestBody Documento documento) {
        Documento nuevoDocumento = documentoService.crearDocumento(documento);
        return ResponseEntity.ok(nuevoDocumento);
    }

    // Eliminar un documento por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarDocumento(@PathVariable int id) {
        documentoService.eliminarDocumento(id);
        return ResponseEntity.noContent().build();
    }
}
