package com.gestiondocumental.controller;

import com.gestiondocumental.model.Auditoria;
import com.gestiondocumental.service.AuditoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/auditorias")
public class AuditoriaController {

    @Autowired
    private AuditoriaService auditoriaService;

    // Obtener todas las auditorías
    @GetMapping
    public List<Auditoria> obtenerTodasLasAuditorias() {
        return auditoriaService.obtenerTodasLasAuditorias();
    }

    // Obtener auditorías por usuario
    @GetMapping("/usuario/{usuarioId}")
    public List<Auditoria> obtenerAuditoriasPorUsuario(@PathVariable int usuarioId) {
        return auditoriaService.obtenerAuditoriasPorUsuarioId(usuarioId);
    }

    // Obtener auditorías por rango de fechas
    @GetMapping("/rango")
    public List<Auditoria> obtenerAuditoriasPorRango(
            @RequestParam("inicio") String inicio,
            @RequestParam("fin") String fin) {
        LocalDateTime fechaInicio = LocalDateTime.parse(inicio);
        LocalDateTime fechaFin = LocalDateTime.parse(fin);
        return auditoriaService.obtenerAuditoriasPorRangoDeFechas(fechaInicio, fechaFin);
    }

    // Registrar una auditoría
    @PostMapping
    public Auditoria registrarAuditoria(@RequestBody Auditoria auditoria) {
        return auditoriaService.registrarAuditoria(auditoria);
    }
}
